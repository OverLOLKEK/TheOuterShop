﻿using Microsoft.AspNetCore.Mvc;
using Shop.Data.Interface;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Shop.Controllers
{
	public class HomeController : Controller
	{
		private readonly IAllHome allHome;
		private readonly IHomeCategory homeCategory;

		public HomeController(IAllHome iAllHome, IHomeCategory ihomeCategory)
		{
			allHome = iAllHome;
			homeCategory = ihomeCategory;
		}
		public ViewResult List()
		{
			var home = allHome.Homes;
			return View();
		}
	}
}
