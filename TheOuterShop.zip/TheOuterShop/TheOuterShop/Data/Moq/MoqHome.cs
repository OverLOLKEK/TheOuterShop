﻿using Shop.Data.Interface;
using Shop.Data.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Shop.Data.Moq
{
	public class MoqHome : IAllHome
	{
		private readonly IHomeCategory homeCategory = new MoqCategory();
		public IEnumerable<Home> AllHome
		{
			get
			{
				return new List<Home>
				{
					new Home {
						Name = "Дом в Византии",
						ShortDesc = "",
						Img = "",
						Price="2500 bit",
						IsFavourite=true,
						Available=true,
						Category=homeCategory.AllCatgories.First()
					},
					new Home {
						Name = "Трудовой барак в Эджуотер"

					}
				};
			}			
		}
		public IEnumerable<Home> GetFavHome { get; set; }

		public IEnumerable<Home> Homes => throw new NotImplementedException();

		public Home GetObjectHome(int HomeId)
		{
			throw new NotImplementedException();
		}
	}
}
