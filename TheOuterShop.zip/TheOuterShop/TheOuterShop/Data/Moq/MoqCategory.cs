﻿using Shop.Data.Interface;
using Shop.Data.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Shop.Data.Moq
{
	public class MoqCategory : IHomeCategory
	{
		public IEnumerable<Category> AllCatgories
		{
			get
			{
				return new List<Category>
				{
					new Category {CategoryName="Fashionable", Desc="Элитные здания для самых успешных "},
					new Category { CategoryName = "Barrack", Desc="Здесь живут обычные рабочие" },
					new Category { CategoryName = "Barrack", Desc="Здесь живут обычные рабочие" }

				};
			}
			set => throw new NotImplementedException();
		}
	}
}
